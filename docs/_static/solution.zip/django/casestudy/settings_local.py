"""Override settings to debug locally outside of Docker."""
from .settings import *  # pylint: disable=wildcard-import, unused-wildcard-import


DATABASES['default']['HOST'] = 'localhost'
CELERY_BROKER_URL = "redis://localhost:6379/1"
CACHES["default"]["LOCATION"] = "redis://localhost:6379/1"
