"""
For more information on setting up DRF views see docs:
https://www.django-rest-framework.org/api-guide/views/#class-based-views
"""
from casestudy.models import Security, Watchlist
from casestudy.price_fetcher import build_stock_cache
from casestudy.serializers import SecuritySerializer, WatchlistSerializer
from casestudy.user_identification import UsernameIdentification
from rest_framework import mixins, permissions, status
from rest_framework.request import Request
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.viewsets import GenericViewSet

from django.contrib.auth import get_user_model, login
from django.db.models import Manager, Q
from django.middleware.csrf import get_token

User = get_user_model()


class LoginView(APIView):
    """Login view for the API."""

    permission_classes = [permissions.AllowAny]

    def post(self, request: Request) -> Response:
        """Login view for the API."""
        username = request.data["username"]
        user = User.objects.get(username=username)
        login(request, user)
        csrftoken = get_token(request)
        return Response(
            {
                "id": user.id,
                "username": user.username,
                "email": user.email,
                "first_name": user.first_name,
                "last_name": user.last_name,
                "csrftoken": csrftoken,
            }
        )


class WatchlistViewSet(  # pylint: disable=too-many-ancestors
    mixins.CreateModelMixin,
    mixins.DestroyModelMixin,
    mixins.ListModelMixin,
    GenericViewSet,
):
    """Watchlist Create/Read/Delete viewset."""

    queryset = Watchlist.objects.all()
    serializer_class = WatchlistSerializer
    permission_classes = [permissions.IsAuthenticated]
    authentication_classes = [UsernameIdentification]
    lookup_field = "security__ticker"

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self._stock_cache = build_stock_cache()

    def get_queryset(self) -> Manager:
        return self.queryset.filter(user=self.request.user)

    def list(self, request, *args, **kwargs):
        watchlist_items = list(self.filter_queryset(self.get_queryset()))
        tickers = [item.security.ticker for item in watchlist_items]
        self._stock_cache.add_subscriptions(tickers)
        prices = self._stock_cache.get_prices(tickers)
        serializer = self.get_serializer(watchlist_items, many=True)
        result = []
        for item in serializer.data:
            price, updated_at = prices[item["security"]["ticker"]]
            result.append(dict(item["security"], price=price, updated_at=updated_at))
        return Response(result)

    def destroy(self, request: Request, *args, **kwargs) -> Response:
        result = super().destroy(request, **kwargs)
        return result

    def create(self, request: Request, *args, **kwargs) -> Response:
        user = request.user
        ticker = request.data["security.ticker"]
        security = Security.objects.get(ticker=ticker)
        item = Watchlist.objects.create(user=user, security=security)
        serializer = self.serializer_class(item)
        return Response(
            serializer.data,
            status=status.HTTP_201_CREATED,
        )


class SecurityView(APIView):
    """Search view for securities"""

    queryset = Security.objects.all()
    permission_classes = [permissions.AllowAny]
    serializer_class = SecuritySerializer
    authentication_classes = []

    def get(self, request: Request) -> Response:
        """Search securities by ticker or name."""
        query = request.query_params["query"]
        securities = self.queryset.filter(Q(ticker=query) | Q(name=query))
        serializer = self.serializer_class(securities, many=True)
        return Response(serializer.data)
