"""Serializers used in DRF views."""

from rest_framework import serializers

from casestudy.models import Security, Watchlist
from django.contrib.auth import get_user_model


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = get_user_model()
        fields = ["id", "username"]


class SecuritySerializer(serializers.ModelSerializer):
    class Meta:
        model = Security
        fields = ['ticker', 'name', 'updated_at']


class WatchlistSerializer(serializers.ModelSerializer):
    security = SecuritySerializer()
    # user = UserSerializer()

    class Meta:
        model = Watchlist
        fields = ['security']
