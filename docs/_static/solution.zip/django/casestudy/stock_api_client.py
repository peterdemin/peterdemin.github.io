from typing import Dict, List

import requests

from django.conf import settings


class StockAPIClient:
    TIMEOUT = 10
    API_KEY_HEADER = "Albert-Case-Study-API-Key"

    def __init__(
        self, session: requests.Session, api_base_url: str, api_key: str
    ) -> None:
        self._session = session
        self._api_base_url = api_base_url
        self._headers = {self.API_KEY_HEADER: api_key}

    def fetch_tickers(self) -> Dict[str, str]:
        """Fetches mapping of ticker to full name for all available securities."""
        response = self._session.get(
            f"{self._api_base_url}tickers/",
            headers=self._headers,
            timeout=self.TIMEOUT,
        )
        response.raise_for_status()
        return response.json()

    def fetch_prices(self, tickers: List[str]) -> Dict[str, float]:
        """Fetches prices for a list of tickers."""
        response = self._session.get(
            f"{self._api_base_url}prices/",
            params={"tickers": ",".join(tickers)},
            headers=self._headers,
            timeout=self.TIMEOUT,
        )
        response.raise_for_status()
        return response.json()


def build_stock_api_client() -> StockAPIClient:
    return StockAPIClient(
        session=requests.Session(),
        api_base_url=settings.ALBERT_CASE_STUDY_API_BASE_URL,
        api_key=settings.ALBERT_CASE_STUDY_API_KEY,
    )
