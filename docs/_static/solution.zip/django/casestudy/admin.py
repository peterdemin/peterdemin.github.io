"""
Django admin for the casestudy app.

The Django admin is a GUI for viewing and managing the database models like 'Security'.
Models registered with the Django admin will be accessible at http://localhost:8000/admin/.

https://docs.djangoproject.com/en/4.2/ref/contrib/admin/
"""
from django.contrib import admin
from casestudy.models import Security, Watchlist


@admin.register(Security)
class SecurityAdmin(admin.ModelAdmin):
    # Fields in the list_display list will appear in the Django admin list view.
    # https://docs.djangoproject.com/en/4.2/ref/contrib/admin/#django.contrib.admin.ModelAdmin.list_display
    list_display = [
        'ticker',
        'name',
        'last_price',
    ]


@admin.register(Watchlist)
class WatchlistAdmin(admin.ModelAdmin):
    # Fields in the list_display list will appear in the Django admin list view.
    # https://docs.djangoproject.com/en/4.2/ref/contrib/admin/#django.contrib.admin.ModelAdmin.list_display
    list_display = [
        'user',
        'security',
    ]
