"""Background tasks.

Shallow interface to Celery tasks.
The dance with a base class and ``process`` attribute is used
to initialize the fetchers lazily and only once.
"""

from casestudy.celery import app
from casestudy.price_fetcher import build_price_fetcher
from casestudy.tickers_fetcher import build_tickers_fetcher
from celery import Task


class FetchTickersTask(Task):
    def __init__(self) -> None:
        self.process = build_tickers_fetcher()


@app.task(bind=True, name="fetch_tickers", ignore_result=True, base=FetchTickersTask)
def fetch_tickers(self):
    return self.process()


class FetchPricesTask(Task):
    def __init__(self) -> None:
        self.process = build_price_fetcher()


@app.task(bind=True, name="fetch_prices", ignore_result=True, base=FetchPricesTask)
def fetch_prices(self):
    return self.process()
