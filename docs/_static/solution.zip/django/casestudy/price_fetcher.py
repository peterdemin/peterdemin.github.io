from casestudy.stock_api_client import build_stock_api_client, StockAPIClient
from casestudy.stock_cache import build_stock_cache, StockCache


class PriceFetcher:
    def __init__(
        self, stock_api_client: StockAPIClient, stock_cache: StockCache
    ) -> None:
        self._stock_api_client = stock_api_client
        self._stock_cache = stock_cache

    def __call__(self) -> None:
        """Fetches prices for monitored securities from external API."""
        subscriptions = self._stock_cache.get_subscriptions()
        if subscriptions:
            self._stock_cache.set_prices(
                self._stock_api_client.fetch_prices(subscriptions)
            )


def build_price_fetcher() -> PriceFetcher:
    return PriceFetcher(
        stock_api_client=build_stock_api_client(),
        stock_cache=build_stock_cache(),
    )
