"""Provides mock for user identification (no authentication)."""
from rest_framework.authentication import BaseAuthentication

from django.contrib.auth import get_user_model


class UsernameIdentification(BaseAuthentication):
    """User X-Username header to identify user."""

    def authenticate(self, request):
        """Resolve User from X-Username HTTP header."""
        username = request.headers.get("X-Username")
        if username:
            user = get_user_model().objects.get(username=username)
        # Unauthenticated, CSRF validation not required
        if not user or not user.is_active:
            return None
        return (user, None)
