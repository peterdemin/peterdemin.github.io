from casestudy.models import Security

from casestudy.stock_api_client import build_stock_api_client, StockAPIClient


class TickersFetcher:
    def __init__(self, stock_api_client: StockAPIClient) -> None:
        self._stock_api_client = stock_api_client

    def __call__(self) -> None:
        """Inserts new tickers into Security DB model."""
        security_names = self._stock_api_client.fetch_tickers()
        existing_tickers = set(Security.objects.values_list("ticker", flat=True))
        new_tickers = [
            (ticker, name)
            for ticker, name in security_names.items()
            if ticker not in existing_tickers
        ]
        if not new_tickers:
            return
        Security.objects.bulk_create(
            Security(ticker=ticker, name=name) for ticker, name in new_tickers
        )


def build_tickers_fetcher() -> TickersFetcher:
    return TickersFetcher(
        stock_api_client=build_stock_api_client(),
    )
