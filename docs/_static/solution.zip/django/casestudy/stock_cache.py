import time
from typing import Dict, List, Tuple

from django_redis.client import DefaultClient

from django.conf import settings
from django.core.cache import cache


class StockCache:
    SUBSCRIPTIONS_KEY = "subscriptions"

    def __init__(
        self, cache_client: DefaultClient, subscription_expire_sec: int
    ) -> None:
        self._cache_client = cache_client
        self._subscription_expire_sec = subscription_expire_sec

    def add_subscriptions(self, tickers: List[str]) -> None:
        """Saves subscriptions for list of tickers."""
        now = time.time()
        self._cache_client.get_client().hset(
            "subscriptions", mapping={ticker: now for ticker in tickers}
        )

    def get_subscriptions(self) -> List[str]:
        """Fetches a list of actively monitored tickers."""
        redis_client = self._cache_client.get_client()
        subscriptions = {
            ticker.decode("utf8"): float(ts_bytes)
            for ticker, ts_bytes in redis_client.hgetall(self.SUBSCRIPTIONS_KEY).items()
        }
        now = time.time()
        cutoff = now - self._subscription_expire_sec
        expired = []
        active = []
        for ticker, created_at in subscriptions.items():
            if created_at < cutoff:
                expired.append(ticker)
            else:
                active.append(ticker)
        if expired:
            redis_client.hdel(self.SUBSCRIPTIONS_KEY, *expired)
            for ticker in expired:
                subscriptions.pop(ticker)
        return list(subscriptions.keys())

    def set_prices(self, prices: Dict[str, float]) -> None:
        """Saves prices to cache."""
        now = time.time()
        self._cache_client.get_client().mset(
            {ticker: f"{now}:{price}" for ticker, price in prices.items()}
        )

    def get_prices(self, tickers: List[str]) -> Dict[str, Tuple[float, float]]:
        """Fetches prices from cache."""
        values = self._cache_client.get_client().mget(tickers)
        prices = {}
        for ticker, value in zip(tickers, values):
            if value:
                updated_at, price = value.split(b":")
                prices[ticker] = (float(price), float(updated_at))
            else:
                prices[ticker] = (None, None)
        return prices


def build_stock_cache() -> StockCache:
    return StockCache(
        cache_client=cache.client,
        subscription_expire_sec=settings.PRICE_SUBSCRIPTION_EXPIRE_SEC,
    )
