import React, { useState, useEffect } from 'react';

export function Search({ handleAddClick }) {
  const [query, setQuery] = useState('');
  const [securities, setSecurities] = useState([]);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const apiUrl = 'http://localhost:8000/security/?';
    // Only make the API call if the query is not empty
    if (query) {
      setIsLoading(true);

      fetch(apiUrl + new URLSearchParams({query: query}))
        .then((response) => {
          if (!response.ok) {
            throw new Error(`Network response was not ok: ${response.status}`);
          }
          return response.json();
        })
        .then((data) => {
          // Assuming the API response is an array of securities
          setSecurities(data);
          setIsLoading(false);
        })
        .catch((error) => {
          console.error('Error fetching data:', error);
          setIsLoading(false);
        });
    }
  }, [query]);

  const handleInputChange = (event) => {
    setQuery(event.target.value);
  };

  return (
    <div>
      <h1>Security Search</h1>
      <label htmlFor="searchInput">Search:</label>
      <input
        type="text"
        id="searchInput"
        value={query}
        onChange={handleInputChange}
        placeholder="Enter a security name or ticker..."
      />
      {isLoading ? (
        <p>Loading...</p>
      ) : (
        <table>
          <thead>
            <tr>
              <th>Ticker</th>
              <th>Name</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {securities.map((security) => (
              <tr key={security.ticker}>
                <td>{security.ticker}</td>
                <td>{security.name}</td>
                <td>
                  <button onClick={() => handleAddClick(security.ticker)}>Add</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
