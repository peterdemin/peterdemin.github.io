import React, { useState, useEffect } from 'react';
import { Search } from "./Search.jsx";

export function Watchlist({ user }) {
  const [securities, setSecurities] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const baseAPIUrl = 'http://localhost:8000/';
  const REFRESH_INTERVAL = 5000;

  useEffect(() => {
    fetchData();
    const intervalId = setInterval(fetchData, REFRESH_INTERVAL);
    return () => clearInterval(intervalId);
  }, []);

  const fetchData = () => {
    // Fetch data from the API using the Fetch API
    const apiUrl = `${baseAPIUrl}watchlist/`;
    fetch(apiUrl, {
        credentials: 'include',
        headers: {
            'X-Username': user.username,
        },
    })
      .then((response) => {
        if (!response.ok) {
          throw new Error(`Network response was not ok: ${response.status}`);
        }
        return response.json();
      })
      .then((data) => {
        // Assuming the API response is an array of securities
        setSecurities(data);
        setIsLoading(false);
      })
      .catch((error) => {
        console.error('Error fetching data:', error);
        setIsLoading(false);
      });
  }

  // Function to reload the watchlist when a security is added
  const reload = () => {
    setIsLoading(true);
    fetchData();
  };

  const handleRemoveClick = (ticker) => {
    // Make a POST request to add the security to the watchlist
    const url = `${baseAPIUrl}watchlist/${ticker}/`;

    fetch(
        url,
        {
            method: 'DELETE',
            credentials: 'include',
            headers: {
                'X-CSRFToken': user.csrftoken,
                'X-Username': user.username
            },
        }
    )
      .then((response) => {
        if (!response.ok) {
          throw new Error(`Network response was not ok: ${response.status}`);
        }
        // Assuming a successful response means the security was removed
        reload();
      })
      .catch((error) => {
        console.error('Error removing security:', error);
      });
  };

  const handleAddClick = (ticker) => {
    // Make a POST request to add the security to the watchlist
    const postUrl = `${baseAPIUrl}watchlist/`;
    const requestBody = JSON.stringify({ "security.ticker": ticker });

    fetch(
        postUrl,
        {
            method: 'POST',
            credentials: 'include',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': user.csrftoken,
                'X-Username': user.username,
            },
            body: requestBody,
        }
    )
      .then((response) => {
        if (!response.ok) {
          throw new Error(`Network response was not ok: ${response.status}`);
        }
        // Assuming a successful response means the security was added
        reload();
      })
      .catch((error) => {
        console.error('Error adding security:', error);
      });
  };

  return (
    <div>
      <Search handleAddClick={handleAddClick} />
      <h1>Securities List</h1>
      {isLoading ? (
        <p>Loading...</p>
      ) : (
        <table>
          <thead>
            <tr>
              <th>Ticker</th>
              <th>Name</th>
              <th>Price</th>
              <th>Last Updated</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {securities.map((security) => (
              <tr key={security.ticker}>
                <td>{security.ticker}</td>
                <td>{security.name}</td>
                <td>{security.price}</td>
                <td>{security.updated_at}</td>
                <td>
                  <button onClick={() => handleRemoveClick(security.ticker)}>Remove</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
