# Case study implementation notes

Please see Design.md for the design considerations.

The main point of the design is that clients do not cause direct API calls to 3rd part API.
Instead they subscribe to price updates for their watchlist.
Subscriptions are renewed on timer from the Javascript side, and expire after 1 minute of inactivity.

Background task fetches prices for active subscriptions every 5 seconds.

The downside of this approach is that user has to wait at least 5 seconds before they can see the fresh price.

Both subscriptions and prices are stored in Redis cache.
Design suggests saving snapshot to the SQL database in case Redis goes down,
but it wasn't implemented as I ran out of time.

I've spent way too much time on project setup tasks, that are done once per project,
such as setting up CORS/CSRF settings.
I don't like the solution I implemented and would like to learn what is the proper way to do it.
Basically, Django CSRF framework relies on session and cookies. And with CORS, browser won't set
the cookies for the API domain (port in case of local development).
What I did is just allowed "X-Username" header in CORS and passed the username in AJAX requests
instead of session cookies and CSRF token.

I wish I figured out that part quicker. Then I would have time to add test coverage.
There's no unit tests, but I'd like to point out how the "meat" is using DI to make unit testing straightforward.
And how framework-facing part (views, serializers, models, tasks) are shallow and do not contain logic.
Can't tell that I'm happy with the implementation, and experienced developer could tell,
that Django/React wasn't may day-to-day driver for at least 4 years.
