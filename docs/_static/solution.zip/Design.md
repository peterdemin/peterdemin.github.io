# Stock watchlist

## Functional requirements
- Users can search for stocks by name or ticker and add them to a watchlist.
- Users can remove a stock from their watchlist.
- Users can see the current price of the stocks in their watchlist.
- The client application must support user login and a single screen that contains a search bar, list of stocks and current prices.
- Possible enhancements:
    - GDPR.
    - Historical view for stock prices.
    - Aggregation of related news.
    - Notifications for stocks performance.
    - Recommendation system for similar stocks.
    - Support for multiple exchanges.
    - Descriptions/media for securities.
    - User account deletion.

## Non-functional requirements
- Performance:
    - Prices should update every 5 seconds.
    - Support millions of users each with their own watchlist.
    - Limit the number of calls to Stock API.
- Consistency:
    - Users should see whether the displayed price is stale (older than 5 sec).
      Alternatively, we can hide the price if it's too old.
- Availability:
    - User data should be persisted in a database and re-used when the app is restarted.
- Security:
    - Don't need to add authentication. The important part here is just to support multiple users.

## Data storage
- Entities:
    - User
        - Attributes: username.
    - Watchlist:
        - Attributes: user_id, security_ticker.
        - Many-to-many between User and Security.
        - Does order of securities in the watchlist matter? Preserve the order of addition in v1.
    - Security
        - Attributes: name, ticker, price.
- Access patterns:
    - Search securities by ticker and by name.
      Proper full-text search can be done using search indexes, such as OpenSearch.
      For the sake of case study, just use complete case-sensitive match in the database.
    - Add/remove security to a watchlist.
    - Update security prices in bulk.
    - Get security prices for a given watchlist.
    - Read-heavy for millions of users and 5 seconds price update interval.
    - Prices should be cached for fast read access.
    - Clients subscribe to price updates, server updates price cache in a centralized way.
- Scalability:
    - Millions of users (watchlists).
    - Hundreds of thousands of securities.
    - Dozens of securities per watchlist.
    - Shard users per user_id or region. (Not implemented)
    - All securities fit into RAM (Redis).
      Still, for the scale-out case, we can shard them by exchange, for example. (Not implemented)

## API
- Login:
    - POST /login/ {"username": "user1"}
- Search securities by ticker or by name:
    - GET /security/?query=<str>. Just use complete match for v1.
- Create/Read/Delete watchlist for authenticated user:
    - POST watchlist/ {"ticker": "AAPL"}
    - GET watchlist/
    - DELETE watchlist/{ticker}
- Pub/sub for price updates:
    - Websocket for low-overhead updates every 5 seconds.
    - Using short-polling for the sake of case study.

## Design
- Data storage:
  - We don't need strong consistency guarantees.
  - We don't have large volumes of unstructured data.
  - So, both SQL and NoSQL solutions would be fine.
    I prefer going with PostgreSQL, since it's easier
    in debugging and more predictable in production.
- Tables:
  - User (PK user_id, username)
  - Security (PK ticker, name, price)
  - Watchlist M2M (user_id, ticker)
- Cache:
  - Price subscriptions:
    - Repopulated every N minutes by each client, that maintains websocket connection.
      Short auto-expire TTL.
  - Batch write security prices to cache every 5 seconds for the active subscriptions.
  - Snapshot prices to persistent DB every N minutes for recovery from cache outage.
- Services:
  - React client:
    - SPA managing user login, security search, watchlist management, and price subscriptions.
  - Web server:
    - Django API managing user login, security search, and watchlist management.
  - Pub/sub server:
    - Websocket server for price subscriptions.
  - Background price fetching server:
    - Background server making Stock API calls:
        - Fetch all securities to populate database.
        - Fetch select prices to populate cache.
    - Many background libraries would do, picking Celery for popularity.
